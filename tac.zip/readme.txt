//////////////////////////////////
///INSTALACE TAC:
//////////////////////////////////
1. Do PATH zkop�rujte obsah adres��e tac z tac.zip 


2. Na ka�dou str�nku webu ihned pod <head> vlo�te scripty:

<!-- TAC Core JS -->
<script src="https://tarteaucitron.io/load.js?domain=www.muj.agel.cz&uuid=0a7d2bfedef14ed96df253b8e4a977dc757c3967"></script>

<!-- Script pro konverzi z default TAC disajnu do AGEL disajnu + inicializace Googe Consent v.2 -->
<script type="text/javascript" src="/PATH/tac/js/tac-convert.js?v=260221"></script>


3. Na ka�dou str�nku webu vl�te css:

<!-- TAC Core CSS-->
<link rel="stylesheet" href="https://tarteaucitron.io/css/tarteaucitron.css">

<!-- Script pro konverzi z default TAC disajnu do AGEL disajnu -->
<link rel="stylesheet" href="/PATH/tac/css/tac-minimal.css">



//////////////////////////////////
///KONFIGURACE:
//////////////////////////////////

V /path/tac/js/tac-convert.js je konfigura�n� ��st. V�e je nakonfigurov�no pro muj.agel.cz.  
